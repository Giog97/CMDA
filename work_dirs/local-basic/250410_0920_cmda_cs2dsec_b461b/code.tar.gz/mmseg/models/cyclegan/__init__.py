from .cyclegan_model import define_G, LightNet

__all__ = [
    'define_G',
    'LightNet'
]
